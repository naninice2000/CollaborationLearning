var =1
while var!="0":
	name = raw_input("Enter student name")
	number = raw_input("Enter student id")
	with open('C:\\Users\\srinivas\\Desktop\\input.txt', 'a') as myFile:
		myFile.write(name+"\t\t " +number+" \n")
	print "data saved successfully"
	var = raw_input("enter any number or 0 to exit")





