import csv

path = 'C:\\Users\\srinivas\\Desktop\\'

file=open( path +"names.csv", "r")
reader = csv.reader(file)

    

with open('C:\\Users\\srinivas\\Desktop\\sample.html', 'w') as myFile:
    myFile.write('<html>')
    myFile.write('<body>')
    myFile.write('<table border="1">')
    myFile.write('<th>Name</th>')

    
    for line in reader:
        myFile.write('<tr><td>%s</td></tr>' % line);
  
    
    myFile.write('</table>')
    myFile.write('</body>')
    myFile.write('</html>')